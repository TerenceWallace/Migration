﻿Namespace Migration
	Public Structure GradingInfo
		Friend Const GradingStrength As Int32 = 3
		Friend AvgHeight As Integer
		Friend Variance As Integer
	End Structure
End Namespace
