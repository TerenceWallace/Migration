﻿Namespace Migration.Interfaces
	Friend Interface IQueueItem
		Property Index() As Integer
		Property F() As Double
	End Interface
End Namespace
