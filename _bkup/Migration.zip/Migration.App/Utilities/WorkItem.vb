﻿Imports Migration.Common

Namespace Migration
	Friend Class WorkItem
		Friend ExpirationCycle As Long
		Friend Handler As Procedure
	End Class
End Namespace
