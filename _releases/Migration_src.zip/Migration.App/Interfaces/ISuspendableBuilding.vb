﻿Namespace Migration.Interfaces
	Public Interface ISuspendableBuilding
		ReadOnly Property IsSuspended() As Boolean
	End Interface
End Namespace
