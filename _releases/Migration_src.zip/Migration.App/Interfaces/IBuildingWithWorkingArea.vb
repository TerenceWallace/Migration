﻿Namespace Migration.Interfaces
	Public Interface IBuildingWithWorkingArea
		Property WorkingRadius() As Integer
	End Interface
End Namespace
