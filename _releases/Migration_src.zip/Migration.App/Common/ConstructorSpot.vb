﻿Imports Migration.Core

Namespace Migration.Common
    Friend Class ConstructorSpot
        Friend Property Position As Point
        Friend Property Direction As Direction
        Friend Property Constructor As Movable
    End Class
End Namespace
