﻿Namespace Migration.Rendering
	Friend Structure DirectionCache
		Public Property DirectionToAnimation() As AnimationSet()
		Public Property DirectionToFrozen() As AnimationSet()
	End Structure
End Namespace
