﻿Imports Migration.Common

Namespace Migration.Rendering
	Friend Class WorkItem
		Public Task As Procedure
		Public ExpirationMillis As Long
	End Class
End Namespace
