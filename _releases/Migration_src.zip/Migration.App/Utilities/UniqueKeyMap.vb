Namespace Migration

	<Serializable> _
	Public Class UniqueKeyMap(Of TKey)
		Inherits UniqueMap(Of TKey, Object)

	End Class

End Namespace
